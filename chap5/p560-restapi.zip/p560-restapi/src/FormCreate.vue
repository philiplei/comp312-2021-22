<script>
export default {
  emits: [ 'cancel', 'confirm' ],
  data() {
    return {
      dialogVisible: false,
      form: { }
    }
  },
  methods: {
    showDialog(record) {
      this.dialogVisible = true;
      this.form.productName = "";
      this.form.category = "";
      this.form.unitPrice = 0;
      this.form.unitsInStock = 0;
    },
    handleCancel() {
      this.dialogVisible = false;
      this.$emit('cancel'); 
    },
    handleConfirm() {
      this.dialogVisible = false;
      this.$emit('confirm', this.form);
    }
  }
}
</script>

<template>
<el-dialog v-model="dialogVisible" title="Add a new product" width="80%">

  <el-form ref="form" :model="form" label-width="120px">
    <el-form-item label="Product name">
      <el-input v-model="form.productName"></el-input>
    </el-form-item>
    <el-form-item label="Category">
      <el-select v-model="form.category" placeholder="please select the category">
        <el-option label="Beverages" value="Beverages"></el-option>
        <el-option label="Condiments" value="Condiments"></el-option>
        <el-option label="Confections" value="Confections"></el-option>
        <el-option label="Dairy Products" value="Dairy Products"></el-option>
        <el-option label="Grains/Cereals" value="Grains/Cereals"></el-option>
        <el-option label="Meat/Poultry" value="Meat/Poultry"></el-option>
        <el-option label="Produce" value="Produce"></el-option>
        <el-option label="Seafood" value="Seafood"></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="Unit price">
      <el-input v-model="form.unitPrice"></el-input>
    </el-form-item>
    <el-form-item label="Units in stock">
      <el-input v-model="form.unitsInStock"></el-input>
    </el-form-item>
  </el-form>

  <template #footer>
    <span class="dialog-footer">
      <el-button @click="handleCancel">Cancel</el-button>
      <el-button type="primary" @click="handleConfirm">Confirm</el-button>
    </span>
  </template>
</el-dialog>

</template>