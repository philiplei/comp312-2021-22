import jsonServer from 'json-server';
const server = jsonServer.create();
const router = jsonServer.router('db.json');
const middlewares = jsonServer.defaults({static: './dist'});

// Set default middlewares (logger, static, cors and no-cache)
server.use(middlewares);
server.use('/api', router);
const port = 8000;
server.listen(port, () => {
  console.log(`This server presents a Web API at http://localhost:${port}/api`);
  console.log('It also serves static files at ./dist.');
  console.log("Before you run this server, 'npm run build' to build the sample web app.");
  console.log(`Next, point your browser to http://localhost:${port}/`);
});