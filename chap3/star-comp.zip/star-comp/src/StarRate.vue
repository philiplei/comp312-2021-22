<script>
import imgStarOn from "./assets/star-on.png";
import imgStarOff from "./assets/star-off.png";
//console.log(imgStarOn);
//console.log(imgStarOff);

export default {
  props: {
    likes: Number,
    maxLikes: Number,    
  },

  emits: [ "update:likes", "deadclick" ],

  data() {
    return {
      clickCount: 0,
      disabled: false,
      starSpanClass: [ "divStars" ],
      imgStarOn, imgStarOff, 
    }
  },

  methods: {
    clickStar(which) {
      console.log(`click star ${which}`);
      this.clickCount++;
      if (!this.disabled) {
        this.$emit("update:likes", which);
        this.disableMeOrNot();
      } else {
        this.$emit("deadclick", this.clickCount);
      }
    },
    disableMeOrNot() {
      if (this.clickCount>5) {
        this.disabled = true;
        this.starSpanClass = [ "divStars", "disableStars" ];
      }
    }
  }
}
</script>

<template>
  <span :class="starSpanClass">
  <img v-for="n in likes" :src="imgStarOn" 
    @click="clickStar(n)">
  <img v-for="n in (maxLikes-likes)" :src="imgStarOff"
    @click="clickStar(likes+n)">
  </span>
</template>

<style scoped>
.divStars { display: inline-block; padding: 4px }
.disableStars {
  background-color: #BBBBBB;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='25' height='25' viewBox='0 0 20 20'%3E%3Cg fill-opacity='0.94'%3E%3Cpolygon fill='%23FFFFFF' points='20 10 10 0 0 0 20 20'/%3E%3Cpolygon fill='%23FFFFFF' points='0 10 0 20 10 20'/%3E%3C/g%3E%3C/svg%3E");
  /* background by SVGBackgrounds.com */
}
</style>