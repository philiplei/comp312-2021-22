<script>
import imgStarOn from "./assets/star-on.png";
import imgStarOff from "./assets/star-off.png";
//console.log(imgStarOn);
//console.log(imgStarOff);

export default {
  props: {
    likes: Number,
    maxLikes: Number,    
  },

  data() {
    return {
      imgStarOn, imgStarOff, 
    }
  }
}
</script>

<template>
  <span class="divStars">
    <img v-for="n in likes" :src="imgStarOn">
    <img v-for="n in (maxLikes-likes)" :src="imgStarOff">
  </span>
</template>

<style scoped>
.divStars { display: inline-block; padding: 4px }
</style>