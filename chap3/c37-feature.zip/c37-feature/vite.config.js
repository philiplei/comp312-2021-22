import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [vue()],

  // the default base is '/'. change to './' for embedded deployment in github.io
  base: "./",

  build: {
    rollupOptions: {
      // rollup.js starts tracing js files for bundling 
      // from these html files
      input: {
        // the default is './index.html', 
        // so this line is actually no required
        index: './index.html',
      }
    }
  }
})
