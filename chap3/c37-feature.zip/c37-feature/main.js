// main.js loaded by HTML

// import 'createApp' from the Vue library as a module
import { createApp } from "vue";

// Vite will pack the css from node_modules to the dist and add a link on the HTML that loads this JavaScript file
// this line is actually not necessary. As long as one of the component import the css, the HTML file will have a link to the css stylesheet.
// import 'element-plus/dist/index.css';

// import the options object from the SFC
import opts from "./app.vue";

const vm = createApp(opts).mount('#app');

// globalThis.vm = vm;
