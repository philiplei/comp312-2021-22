import { createApp } from 'vue';
import App from './App.vue';

let vm = createApp(App).mount('#app');

globalThis.vm = vm;