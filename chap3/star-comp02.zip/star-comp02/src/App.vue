<script>
import StarRate from "./StarRate.vue";

export default {
  components: { StarRate },
  data() {
    return {
      current: 4, max: 7
    }
  }
}
</script>

<template>
  <p>Rating of this lecture is {{current}} out of {{ max }}</p>
  <star-rate v-model:likes="current" :max-likes="max"></star-rate>
</template>

<style scoped>
</style>