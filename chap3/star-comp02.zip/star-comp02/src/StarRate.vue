<script>
import imgStarOn from "./assets/star-on.png";
import imgStarOff from "./assets/star-off.png";
//console.log(imgStarOn);
//console.log(imgStarOff);

export default {
  props: {
    likes: Number,
    maxLikes: Number,    
  },

  emits: [ "update:likes" ],

  data() {
    return {
      imgStarOn, imgStarOff, 
    }
  },

  methods: {
    clickStar(which) {
      console.log(`click star ${which}`);
      this.$emit("update:likes", which);
    }
  }
}
</script>

<template>
  <span class="divStars">
  <img v-for="n in likes" :src="imgStarOn" 
    @click="clickStar(n)">
  <img v-for="n in (maxLikes-likes)" :src="imgStarOff"
    @click="clickStar(likes+n)">
  </span>
</template>

<style scoped>
.divStars { display: inline-block; padding: 4px }
</style>