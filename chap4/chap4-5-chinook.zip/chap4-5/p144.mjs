// p144.mjs
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

const db = await open({
  filename: './chinook.sqlite',
  driver: sqlite3.Database
});

async function exportTrack () {
  const queryTrack = 
  `SELECT * FROM Track LIMIT 1000 OFFSET 2000`;
  const prom = db.each(queryTrack, {} , (err, row) => {
    if (err) throw err;
    console.log(row);
  }); 
  // returns number of records in result set
  return await prom;
}   

const trackCount = await exportTrack();
console.log("Track count =", trackCount);
await db.close();