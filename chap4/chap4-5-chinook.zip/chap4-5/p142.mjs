// p142.mjs
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

const db = await open({
  filename: './chinook.sqlite',
  driver: sqlite3.Database
});

const query = 
 `SELECT TrackId as id, tr.Name as name, milliseconds as length 
  FROM Track as tr
  JOIN MediaType as mt ON tr.MediaTypeId = mt.MediaTypeId
  WHERE milliseconds>$trackLength
  AND mt.Name LIKE '%AAC%'
  ORDER BY length DESC`;

const longTrack = await db.all(query, { $trackLength: 600000});
console.log(longTrack);

await db.close();