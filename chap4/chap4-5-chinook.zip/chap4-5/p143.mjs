// p143.mjs
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

const db = await open({
  filename: './chinook.sqlite',
  driver: sqlite3.Database,
  logger: console.log
});

async function getInvoiceAmount (invoiceId) {
  const queryInvoiceAmount =
    `SELECT SUM(UnitPrice*Quantity) as invoiceAmount 
    FROM InvoiceLine
    WHERE InvoiceId = $invoiceId`;
  const result = await db.get(queryInvoiceAmount, 
    { $invoiceId: invoiceId });
  return result.invoiceAmount;
}

async function getXmasInvoice () {
  const queryInvoice = 
  `SELECT InvoiceId as id, InvoiceDate as invDate
   FROM Invoice
   WHERE InvoiceDate BETWEEN $startInvoiceDate AND $endInvoiceDate`;
  const xmasInvoice = await db.all(queryInvoice, { $startInvoiceDate: "2012-12-01", $endInvoiceDate: "2012-12-31" } );
  for (let invoice of xmasInvoice) {
    invoice.invAmount = await getInvoiceAmount(invoice.id); 
  }
  return xmasInvoice;
}   

const xmasInvoice = await getXmasInvoice();
console.table(xmasInvoice);

await db.close();