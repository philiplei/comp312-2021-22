class Circle {
  // create a Circle object at (x,y) with the given radius
  constructor (x, y, radius) {
    this.x = x;
    this.y = y;
    this.radius = radius;
  }
  // define a method for Circle object
  area () {
    return this.radius * this.radius * Math.PI;
  }
  // override the default toString method
  toString () {
    return `a circle at (${this.x},${this.y}) of radius ${this.radius}`;
  }
  move (x,y) {
    this.x = x;
    this.y = y;
  }
}

// check whether the Circle c1 fully contains the Circle c2
function contains (c1, c2) {
  // calculate distance between center of the two circles
  let dist = Math.sqrt(Math.pow(c1.x-c2.x, 2) + Math.pow(c1.y-c2.y, 2));
  return (dist < c1.radius-c2.radius);
}

// make a default export module object which has two properties:
// 'Circle' is a class
// 'contains' is a function
export default { Circle, contains }

// the above is a concise way to write the following 
/*
export default {
  Circle: Circle,
  contains: contains    
}
*/