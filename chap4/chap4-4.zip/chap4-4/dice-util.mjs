// dice-util.mjs

// internal function, not exported
function randomInteger(min, max) {
  return Math.floor(Math.random()*(max-min+1))+min
}

export function rollDice (count, face) {
  // assume count > 0, face > 1, integers
  let result = [ ];
  for (let n=0; n<count; n++) {
    result.push(randomInteger(1,face));  
  }
  return result;
}

export function rollDiceSum (count, face) {
  // assume count > 0, face > 1, integers
  let sum = 0;
  for (let n=0; n<count; n++) {
    sum += randomInteger(1,face);  
  }
  return sum;
}