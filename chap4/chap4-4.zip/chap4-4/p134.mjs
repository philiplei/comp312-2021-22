import prompts from 'prompts';
import figlet from 'figlet';

prompts({
  type: 'text',
  name: 'sentence',
  message: 'Type a short sentence'
}).then( data=> {
  figlet(data.sentence, function(err, data) {
    if (err) throw err;
    console.log(data)
  });
});
