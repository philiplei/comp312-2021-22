import { rollDice, rollDiceSum } from './dice-util.mjs';

let sixDice = rollDice(6, 10);
console.log(`Roll six dice of 10 faces and get ${sixDice}.`)

let diceSum = rollDiceSum(10, 6)
console.log(`Roll 10 dice of 6 faces and their sum is ${diceSum}.`);
