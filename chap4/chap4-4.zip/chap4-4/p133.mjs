// p133.mjs
import cc from './circle.mjs'

let c = new cc.Circle(1,2,10);
let a = c.area();
console.log(`The area is ${a}.`);
// this calls c.toString()
console.log(`c is ${c}`);
// c is a circle at (1,2) of radius 10
c.move(-1,0);
console.log(`c is ${c}`);
// c is a circle at (-1,0) of radius 10

let c1 = new cc.Circle(0, 0, 10);
let c2 = new cc.Circle(3, 4, 4);
let c3 = new cc.Circle(3, 4, 8);
console.log('c1 contains c2? ', cc.contains(c1,c2) );
console.log('c1 contains c3? ', cc.contains(c1,c3) );

