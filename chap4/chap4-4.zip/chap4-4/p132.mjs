import { evaluate, inv } from 'mathjs';

console.log(`sqrt(-1) = ${evaluate("sqrt(-1)")}`);
console.log(`sqrt(i) = ${evaluate("sqrt(i)")}`);

const mat = [ [1,2], [3,4] ];
console.log("A matrix: ", mat)
console.log("and its inverse: ", inv(mat));