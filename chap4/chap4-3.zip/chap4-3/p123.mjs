import { readFile, writeFile } from 'fs/promises';

readFile('mpi-info.txt', 'utf8').then( data=>{
  // data contains content of the input file
  return writeFile('copy-mpi-info.txt', data, 'utf8')
}).then( ()=>{
  console.log("Finish copying");  
})