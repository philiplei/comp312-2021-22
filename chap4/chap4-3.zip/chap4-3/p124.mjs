import { readFile, writeFile } from 'fs/promises';

readFile('non-exist-mpi-info.txt', 'utf8').then( data=>
  writeFile('copy-mpi-info.txt', data, 'utf8')
).then( ()=>{
  console.log("Finish copying");  
}).catch( err=>{
  console.error("promise catch "+err);
})