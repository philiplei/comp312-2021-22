function tossDice() {
  const timeTaken = 3000;
  const tossFailed = Math.random() < 0.1;
  const tossResult = Math.floor(Math.random()*6)+1; 
  let promise = new Promise((resolve, reject) => {
    setTimeout(()=>{
      if (tossFailed) { 
        reject("toss fails") 
      } else { 
        resolve(tossResult) 
      }
    }, timeTaken)
  });
  return promise;
}

tossDice().then(res=>{console.log(res)})
  .catch(err=>{console.log('error: '+err)})