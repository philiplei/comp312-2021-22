import { readFile, writeFile } from 'fs/promises';

try {
  let data = await readFile('mpi-info.txt', 'utf8');
  await writeFile('copy-mpi-info.txt', data, 'utf8');
  console.log("Finish copying");  
} catch (err) {
  console.error("promise catch "+err);
}