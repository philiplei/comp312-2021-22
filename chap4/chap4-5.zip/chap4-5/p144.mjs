// p144.mjs
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

const db = await open({
  filename: './my-northwind.sqlite',
  driver: sqlite3.Database
});

async function exportOrderDetail () {
  const queryOrderDetail = 
   `SELECT * FROM OrderDetail LIMIT 500 OFFSET 1000`;
  const prom = db.each(queryOrderDetail, {} , (err, row) => {
    if (err) throw err;
    console.log(row);
  }); 
  // returns number of records in result set
  return await prom;
}    

const recordCount = await exportOrderDetail();
console.log("count =", recordCount);

await db.close();