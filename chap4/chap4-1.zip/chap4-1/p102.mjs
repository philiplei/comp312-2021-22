// p102.mjs
// countdown from 10
let N = 10;

function tick() {
  if (N<=0) {
    console.log('Time\'s up!');
    clearInterval(timer);
  } else {
    console.log(N); N--;
  }
}

// this starts the timer
const timer = setInterval(tick, 1000);

// event loop goes here ...
